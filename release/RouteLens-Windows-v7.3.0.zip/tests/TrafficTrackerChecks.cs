using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using RouteLens;

internal static class TrafficTrackerChecksV6
{
    private static int checks;
    private static readonly DateTime At = new DateTime(2020, 1, 1, 0, 0, 0);

    private static void Check(bool condition, string description)
    {
        checks++;
        if (!condition)
        {
            Console.Error.WriteLine("FAILED after " + checks + " checks: " + description);
            throw new Exception("FAILED: " + description);
        }
    }
    private static void Near(double actual, double expected, string description)
    {
        Check(Math.Abs(actual - expected) < .001, description + ": " + actual);
    }
    private static ConnectionInfo Row(string id, long down, long up)
    {
        return new ConnectionInfo { Id = id, DownloadBytes = down, UploadBytes = up,
            DataSource = "Clash / Mihomo", ProcessName = "Example.exe", ProcessPath = @"C:\Apps\Example.exe",
            ProcessId = 111, Protocol = "TCP", LocalAddress = "192.0.2.1", LocalPort = 20000,
            RemoteAddress = "198.51.100.1", RemotePort = 443 };
    }
    private static NetworkSnapshot Snapshot(int second, params ConnectionInfo[] rows)
    {
        return new NetworkSnapshot { CapturedAt = At.AddSeconds(second), ClashConnected = true,
            SourceName = "Clash / Mihomo", ControllerSummary = "fictional controller",
            Connections = new List<ConnectionInfo>(rows) };
    }
    private static TrafficReport Accept(TrafficTracker tracker, NetworkSnapshot snapshot)
    {
        tracker.Update(snapshot);
        return tracker.Build(snapshot.Connections, false);
    }

    private static ConnectionInfo Site(string id, string host, string route, long down, long up)
    {
        ConnectionInfo row = Row(id, down, up); row.Host = host; row.RouteType = route;
        return row;
    }

    private static void DailySites()
    {
        TrafficTracker tracker = new TrafficTracker();
        DailySiteTraffic daily = new DailySiteTraffic();
        Action<int, ConnectionInfo[]> sample = delegate(int second, ConnectionInfo[] rows) { tracker.Update(Snapshot(second, rows), daily); };
        sample(0, new[] { Site("a", "One.test", "直连", 1000, 100), Site("b", "one.test.", "代理", 700, 80), Site("c", "", "拒绝", 20, 1) });
        Check(daily.Read(At).Sites.Count == 0, "baseline does not count old traffic");
        sample(1, new[] { Site("a", "One.test", "直连", 1060, 110), Site("b", "one.test.", "代理", 730, 85), Site("c", "", "拒绝", 23, 2) });
        DailySiteTrafficReport first = daily.Read(At);
        Check(first.DownloadBytes == 93 && first.UploadBytes == 16 && first.TotalBytes == 109 &&
            first.DirectBytes == 70 && first.ProxyBytes == 35 && first.UnknownBytes == 4, "day partitions actual bytes by route");
        Check(first.Sites.Count == 2 && first.Sites[0].TotalBytes == 105 && first.Sites[0].DownloadBytes == 90 &&
            first.Sites[0].UploadBytes == 15 && first.Sites[0].DirectBytes == 70 && first.Sites[0].ProxyBytes == 35 &&
            first.Sites[1].Host == "198.51.100.1", "site grouping, IP fallback, ranked totals");
        Check(daily.Read(At, false).Sites.Count == 0 && daily.Read(At, false).TotalBytes == 109, "cheap summary keeps exact totals");
        sample(1, new[] { Site("a", "One.test", "直连", 1, 1) });
        sample(0, new[] { Site("a", "One.test", "直连", 0, 0) });
        sample(2, new[] { Site("a", "One.test", "代理", 1070, 110), Site("new", "new.test", "直连", 6000, 900) });
        Check(daily.Read(At).TotalBytes == 119 && daily.Read(At).UnknownBytes == 14, "replay/old sample do not replace baseline; changed route is unknown");
        sample(3, new[] { Site("a", "One.test", "代理", 1080, 110), Site("a", "One.test", "代理", 1090, 110) });
        sample(4, new[] { Site("a", "One.test", "代理", 1200, 130) });
        ConnectionInfo missing = Site("a", "One.test", "代理", 1300, 140); missing.HasTrafficCounters = false;
        sample(5, new[] { missing });
        sample(6, new[] { Site("a", "One.test", "代理", 1400, 150) });
        sample(7, new[] { Site("a", "One.test", "代理", 5, 0) });
        tracker.Reset();
        sample(8, new[] { Site("a", "One.test", "代理", 1500, 160) });
        sample(20, new[] { Site("a", "One.test", "代理", 1600, 170) });
        Check(daily.Read(At).TotalBytes == 119, "ambiguous IDs, missing/reset counters, pause and gaps do not invent bytes");
        sample(21, new[] { Site("a", "One.test", "代理", 1604, 171) });
        sample(22, new ConnectionInfo[0]);
        Check(daily.Read(At).TotalBytes == 124 && first.TotalBytes == 109, "closed sites retained, detached reports stable");
        daily.Clear();
        sample(23, new[] { Site("a", "One.test", "代理", 150, 40) });
        daily.Clear();
        sample(24, new[] { Site("a", "One.test", "代理", 250, 45) });
        Check(daily.Read(At).TotalBytes == 0, "clear drops old interval");
        sample(25, new[] { Site("a", "One.test", "代理", 251, 46) });
        Check(daily.Read(At).TotalBytes == 2 && daily.Read(At).Sites.Count == 1, "clear starts fresh after next baseline");
        sample(86399, new[] { Site("a", "One.test", "代理", 800, 90) });
        Check(daily.Read(At.AddDays(1)).TotalBytes == 0, "day resets on read even with sampling paused");
        sample(86400, new[] { Site("a", "One.test", "代理", 820, 92) });
        sample(86399, new[] { Site("a", "One.test", "代理", 1, 0) });
        sample(86401, new[] { Site("a", "One.test", "代理", 826, 95) });
        Check(daily.Read(At.AddDays(1)).Day == At.AddDays(1) && daily.Read(At.AddDays(1)).TotalBytes == 9,
            "midnight straddling interval excluded; late yesterday packet ignored");
        NetworkSnapshot native = Snapshot(86402, Site("a", "One.test", "代理", 1000, 150)); native.ClashConnected = false;
        tracker.Update(native, daily);
        sample(86403, new[] { Site("a", "One.test", "代理", 1200, 155) });
        NetworkSnapshot other = Snapshot(86404, Site("a", "One.test", "代理", 1600, 185)); other.ControllerSummary = "another controller";
        tracker.Update(other, daily);
        Check(daily.Read(At.AddDays(1)).TotalBytes == 9, "source and controller changes do not invent bytes");

        DailySiteTraffic bounded = new DailySiteTraffic(); bounded.Read(At);
        for (int i = 0; i <= DailySiteTraffic.MaximumSites; i++) bounded.Add(Site("i", "h" + i + ".test", "直连", 0, 0), 1, 2, "直连");
        DailySiteTrafficReport limited = bounded.Read(At);
        Check(limited.Sites.Count == DailySiteTraffic.MaximumSites && limited.OverflowBytes == 3 && limited.DirectBytes == 3L * (DailySiteTraffic.MaximumSites + 1),
            "site capacity keeps exact route totals and tracks grouped overflow");
        bounded.Add(Site("i", "h0.test", "代理", 0, 0), Int64.MaxValue, Int64.MaxValue, "代理");
        Check(bounded.Read(At).TotalBytes == Int64.MaxValue && bounded.Read(At).Sites[0].TotalBytes == Int64.MaxValue, "daily totals saturate without wrapping");
    }

    private static void Main()
    {
        TrafficTracker tracker = new TrafficTracker();
        ConnectionInfo first = Row("a", 1000, 200);
        TrafficReport report = Accept(tracker, Snapshot(0, first));
        Check(report.Available && !report.Measuring, "first sample supports cumulative but no invented rate");
        Check(report.DownloadBytes == 1000 && report.CounterConnectionCount == 1, "first cumulative retained");
        ConnectionInfo a = Row("a", 1600, 300), b = Row("b", 900, 90);
        b.ProcessId = 222;
        report = Accept(tracker, Snapshot(2, a, b));
        Check(report.Programs.Count == 1 && report.Programs[0].Connections == 2, "same path across instances grouped");
        Check(report.Measuring && report.MeasuredConnectionCount == 1, "new connection is not retroactively timed");
        Near(report.DownloadPerSecond, 300, "download delta divided by seconds");
        Near(report.UploadPerSecond, 50, "upload delta divided by seconds");
        Check(report.DownloadBytes == 2500 && report.UploadBytes == 390, "active cumulative sum");
        report = tracker.Build(new[] { b }, false);
        Check(!report.Measuring && report.DownloadBytes == 900, "filtered subset excludes other program connection rates");
        report = tracker.Build(new[] { a }, false);
        Near(report.DownloadPerSecond, 300, "Build does not consume or modify rate");
        report = tracker.Build(new[] { a, a }, false);
        Check(report.ConnectionCount == 1 && report.DownloadBytes == 1600, "duplicate enumeration not double counted");
        report = tracker.Build(new[] { a }, true);
        Check(report.Available && !report.Measuring && report.DownloadPerSecond == 0 && report.DownloadBytes == 1600,
            "pause keeps cumulative and hides speed");
        a = Row("a", 1800, 340); b = Row("b", 900, 90); b.ProcessId = 222;
        report = Accept(tracker, Snapshot(3, a, b));
        Check(report.MeasuredConnectionCount == 2, "second new-connection sample measured");
        Near(report.DownloadPerSecond, 200, "idle measured connection adds genuine zero");
        report = Accept(tracker, Snapshot(4, Row("a", 100, 350)));
        Check(!report.Measuring && report.DownloadPerSecond == 0, "counter decrease invalidates rate");
        report = Accept(tracker, Snapshot(5, Row("a", 200, 360)));
        Near(report.DownloadPerSecond, 100, "counter reset recovers from fresh baseline");
        Check(report.ConnectionCount == 1 && report.DownloadBytes == 200, "closed connections leave cumulative totals");

        ConnectionInfo changed = Row("a", 400, 380); changed.RemoteAddress = "203.0.113.2";
        report = Accept(tracker, Snapshot(6, changed));
        Check(!report.Measuring, "reused identifier with different endpoint resets");
        changed = Row("a", 600, 400); changed.ProcessPath = @"C:\Other\Example.exe";
        report = Accept(tracker, Snapshot(7, changed));
        Check(!report.Measuring, "reused identifier with different program resets");
        NetworkSnapshot otherController = Snapshot(8, changed); otherController.ControllerSummary = "other fictional controller";
        report = Accept(tracker, otherController);
        Check(!report.Measuring, "controller change resets");
        report = Accept(tracker, Snapshot(9, Row("a", 800, 410)));
        Check(!report.Measuring, "controller changed back still needs baseline");
        report = Accept(tracker, Snapshot(15, Row("a", 1000, 420)));
        Check(!report.Measuring, "long sample gap is not shown as live speed");
        report = Accept(tracker, Snapshot(15, Row("a", 1200, 430)));
        Check(!report.Measuring, "zero time gap has no division or fabricated speed");
        report = Accept(tracker, Snapshot(14, Row("a", 1400, 440)));
        Check(!report.Measuring, "backward clock jump has no negative speed");
        report = Accept(tracker, Snapshot(15, Row("a", 1500, 450)));
        Near(report.DownloadPerSecond, 100, "clock jump recovers next interval");
        typeof(TrafficTracker).GetField("_receivedAt", BindingFlags.NonPublic | BindingFlags.Instance)
            .SetValue(tracker, Stopwatch.GetTimestamp() - 6 * Stopwatch.Frequency);
        report = tracker.Build(new[] { Row("a", 1500, 450) }, false);
        Check(report.Available && !report.Measuring && report.Status.Contains("过期"), "stale wall age hides speed independent of historical fixture date");
        report = Accept(tracker, Snapshot(16, Row("a", 1800, 460)));
        Check(!report.Measuring, "stale reception gap resets baseline even if capture timestamps are close");
        report = Accept(tracker, Snapshot(17, Row("a", 1900, 470)));
        Near(report.DownloadPerSecond, 100, "fresh after stale resumes normally");
        NetworkSnapshot error = Snapshot(18, Row("a", 2000, 480)); error.Error = "fictional error";
        report = Accept(tracker, error);
        Check(!report.Available && !report.Measuring && report.DownloadBytes == 0, "failed read never displays stale cumulative");
        report = Accept(tracker, Snapshot(19, Row("a", 2200, 490)));
        Check(report.Available && !report.Measuring, "recovery starts new baseline");
        NetworkSnapshot native = Snapshot(20, Row("a", 2400, 500)); native.ClashConnected = false;
        report = Accept(tracker, native);
        Check(!report.Available && !report.Measuring, "Windows source has no guessed traffic");
        tracker.Reset();
        report = Accept(tracker, Snapshot(21, Row("a", 2600, 510)));
        Check(!report.Measuring, "explicit reset prevents paused interval averaging");
        Check(first.DownloadBytes == 1000 && first.UploadBytes == 200 && first.ProcessName == "Example.exe", "external connection data unchanged");

        ConnectionInfo missing = Row("m", 100, 10); missing.HasTrafficCounters = false;
        ConnectionInfo inferred = Row("i", 200, 20); inferred.HasTrafficCounters = null;
        ConnectionInfo noSource = Row("n", 300, 30); noSource.HasTrafficCounters = null; noSource.DataSource = "Windows";
        ConnectionInfo negative = Row("x", -1, 40); negative.HasTrafficCounters = true;
        report = Accept(tracker, Snapshot(22, missing, inferred, noSource, negative));
        Check(report.Available && report.ConnectionCount == 4 && report.CounterConnectionCount == 1, "counter presence enforced, legacy Clash null supported");
        Check(report.DownloadBytes == 200 && report.Status.Contains("3 条连接未提供计数"), "missing counters not silently summed as zero");
        missing = Row("m", 10000, 500); missing.HasTrafficCounters = true;
        report = Accept(tracker, Snapshot(23, missing));
        Check(!report.Measuring, "missing counters do not supply future rate baseline");
        report = Accept(tracker, Snapshot(24, Row("m", 10100, 600)));
        Near(report.DownloadPerSecond, 100, "restored counters recover on second sample");
        ConnectionInfo idle = Row("zero", 0, 0); idle.HasTrafficCounters = true;
        Accept(tracker, Snapshot(25, idle));
        report = Accept(tracker, Snapshot(26, Row("zero", 0, 0)));
        Check(report.Measuring && report.MeasuredConnectionCount == 1 && report.DownloadPerSecond == 0, "valid zero rate differs from waiting");

        ConnectionInfo unknownA = Row("ua", 2, 1), unknownB = Row("ub", 3, 1), namedNoPid = Row("np", 4, 1);
        unknownA.ProcessPath = unknownB.ProcessPath = namedNoPid.ProcessPath = "";
        unknownA.ProcessName = "PID 111"; unknownB.ProcessName = "已结束 / 无归属"; namedNoPid.ProcessName = "Known.exe";
        unknownA.ProcessId = 111; unknownB.ProcessId = namedNoPid.ProcessId = 0;
        report = Accept(tracker, Snapshot(27, unknownA, unknownB, namedNoPid));
        Check(report.Programs.Count == 2, "unknown PIDs are not represented as identified programs");
        ProgramTraffic unknown = report.Programs.Find(delegate(ProgramTraffic p) { return p.Name == "未识别程序"; });
        Check(unknown != null && unknown.Connections == 2 && unknown.DownloadBytes == 5, "unknown attribution is explicit bucket");
        Check(report.Programs.Exists(delegate(ProgramTraffic p) { return p.Name == "Known.exe"; }), "known Clash name valid without native PID");

        ConnectionInfo p1 = Row("p1", 2, 1), p2 = Row("p2", 3, 1), p3 = Row("p3", 4, 1);
        p1.ProcessPath = @"C:\Apps\Example.exe"; p2.ProcessPath = @"c:/apps/EXAMPLE.exe"; p3.ProcessPath = @"D:\Apps\Example.exe";
        report = Accept(tracker, Snapshot(28, p1, p2, p3));
        Check(report.Programs.Count == 2, "paths normalized case-insensitively without merging different installs");
        ConnectionInfo huge1 = Row("h1", Int64.MaxValue, Int64.MaxValue), huge2 = Row("h2", Int64.MaxValue, Int64.MaxValue);
        report = Accept(tracker, Snapshot(29, huge1, huge2));
        Check(report.DownloadBytes == Int64.MaxValue && report.UploadBytes == Int64.MaxValue, "cumulative arithmetic saturates safely");
        Check(report.Programs[0].DownloadBytes == Int64.MaxValue, "program cumulative saturates safely");
        report = Accept(tracker, Snapshot(30, Row("dup", 100, 10), Row("dup", 900, 90)));
        Check(!report.Measuring && report.ConnectionCount == 1, "duplicate id cannot generate a speed or double count");
        report = Accept(tracker, Snapshot(31, Row("dup", 1000, 100)));
        Check(!report.Measuring, "ambiguous duplicate id cannot form next baseline");
        report = Accept(tracker, Snapshot(32, Row("", 2, 1)));
        Check(report.Available && !report.Measuring && report.DownloadBytes == 2, "missing id permits cumulative only");
        report = tracker.Build(new ConnectionInfo[0], false);
        Check(report.Available && !report.Measuring && report.ConnectionCount == 0 && report.Status.Contains("没有连接"), "empty filter accurate");
        tracker.Update(null);
        Check(!tracker.Build(null, false).Available, "null snapshot clears state safely");
        ConnectionInfo ta = Row("target-a", 100, 100), tb = Row("target-b", 100, 100), tc = Row("target-c", 100, 100);
        ta.Host = "upload.example"; tb.Host = "idle.example"; tc.Host = "unknown.example"; tc.HasTrafficCounters = false;
        Accept(tracker, Snapshot(40, ta, tb, tc));
        ta = Row("target-a", 200, 150); tb = Row("target-b", 200, 100); tc = Row("target-c", 200, 200);
        ta.Host = "upload.example"; tb.Host = "idle.example"; tc.Host = "unknown.example"; tc.HasTrafficCounters = false;
        report = Accept(tracker, Snapshot(41, ta, tb, tc));
        Check(report.Fresh && report.Targets.Count == 3, "fresh observed targets returned");
        Check(report.Targets.Find(x => x.Name == "upload.example").PositiveUpload, "upload target requires positive measured upload delta");
        Check(report.Targets.Find(x => x.Name == "idle.example").Measured && !report.Targets.Find(x => x.Name == "idle.example").PositiveUpload, "zero upload is not classified as positive");
        Check(!report.Targets.Find(x => x.Name == "unknown.example").Measured && !report.Targets.Find(x => x.Name == "unknown.example").PositiveUpload, "missing counter is not classified as uploaded");
        report = tracker.Build(new[] { ta, tb, tc }, true);
        Check(!report.Fresh && !report.Targets.Exists(x => x.PositiveUpload), "paused target observations cannot claim current upload");
        ConnectionInfo changedHost = Row("target-a", 300, 250); changedHost.Host = "other.example";
        report = Accept(tracker, Snapshot(42, changedHost));
        Check(!report.Measuring && !report.Targets[0].PositiveUpload, "changed host cannot inherit earlier target's upload delta");
        DailySites();
        Console.WriteLine("Traffic tracker passed " + checks + " checks.");
    }
}
