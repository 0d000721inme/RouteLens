using System;
using System.Collections.Generic;
using System.Linq;
using RouteLens;

internal static class ActivityAlertsChecks
{
    private static int checks;
    [STAThread] private static int Main()
    {
        try { Run(); SustainedUpload(); ProgramDownloads(); Console.WriteLine("PASS " + checks + " session alert checks; fictional data only, no network or disk history."); return 0; }
        catch (Exception ex) { Console.Error.WriteLine("FAIL " + ex.Message); return 1; }
    }
    private const long MiB = 1024 * 1024;
    private static ConnectionInfo Download(string id, string name, long bytes)
    { return Row(id, @"C:\Private\" + name, name, 42, "192.0.2.1", bytes); }

    private static void ProgramDownloads()
    {
        DateTime start = new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc), clock = start;
        ActivityAlerts alerts = new ActivityAlerts(delegate { return clock; });
        List<string> events = new List<string>(); alerts.Alert += events.Add;
        Check(!alerts.ProgramDownloadEnabled && alerts.ProgramDownloadBytesPerSecond == 10 * MiB && alerts.ProgramDownloadSeconds == 5, "Download defaults incorrect");
        alerts.Enabled = true; alerts.ProgramDownloadEnabled = true;
        alerts.ProgramDownloadBytesPerSecond = 2 * MiB; alerts.ProgramDownloadSeconds = 3;

        // A has two connections. B is initially below threshold, and the unnamed
        // group has heavy traffic throughout. All three start with old totals.
        Action<int, int, int, string> sample = delegate(int second, int aBytesMiB, int bBytesMiB, string aName)
        {
            ConnectionInfo unknown = Row("u", null, "未识别程序", 0, "192.0.2.1", (100 + second * 20L) * MiB);
            alerts.Update(Snapshot(start.AddSeconds(second), "Clash", Download("a1", aName, (70 + aBytesMiB) * MiB),
                Download("a2", aName, (40 + aBytesMiB) * MiB), Download("b", "b.exe", (10 + bBytesMiB) * MiB), unknown), null);
        };
        sample(0, 0, 0, "a.exe"); sample(1, 1, 1, "a.exe");
        Check(events.Count == 0, "Download fired on baseline or before duration");
        sample(3, 5, 3, "a.exe");
        Check(events.Count == 1 && events[0].Contains("a.exe") && events[0].Contains("3 秒") &&
            events[0].Contains("3.33 MiB/s") && events[0].Contains("共 10 MiB"), "Per-program download totals, weighted rate or duration incorrect");
        Check(!events[0].Contains("Private") && !events[0].Contains("192.0.2") && !events[0].Contains("example.test"), "Private target or path in download notification");
        sample(6, 8, 9, "A.EXE");
        Check(events.Count == 2 && events[1].Contains("b.exe"), "Per-program cooldown or independent attribution failed");
        clock = start.AddMinutes(5); sample(7, 9, 11, "A.EXE");
        Check(events.Count == 4, "Programs did not rearm after cooldown");

        foreach (string reason in new[] { "missing counter", "counter rollback", "pause", "gap", "Windows", "disappeared", "slow", "controller" })
            CheckDownloadBreak(start, reason);
        bool rejected = false; try { alerts.ProgramDownloadBytesPerSecond = Double.NaN; } catch (ArgumentOutOfRangeException) { rejected = true; }
        Check(rejected, "Invalid download threshold accepted");
        rejected = false; try { alerts.ProgramDownloadSeconds = Double.PositiveInfinity; } catch (ArgumentOutOfRangeException) { rejected = true; }
        Check(rejected, "Invalid download duration accepted");
    }

    private static void CheckDownloadBreak(DateTime start, string reason)
    {
        ActivityAlerts alerts = new ActivityAlerts(delegate { return start; }) { Enabled = true, ProgramDownloadEnabled = true,
            ProgramDownloadBytesPerSecond = MiB, ProgramDownloadSeconds = 3 };
        List<string> events = new List<string>(); alerts.Alert += events.Add;
        Action<int> sample = delegate(int second)
        { alerts.Update(Snapshot(start.AddSeconds(second), "Clash", Download("a", "app.exe", (10L + second) * MiB)), null); };
        sample(0); sample(1); sample(2);
        int next = reason == "gap" ? 12 : 3;
        ConnectionInfo a = Download("a", "app.exe", (10L + next) * MiB);
        NetworkSnapshot interruption = Snapshot(start.AddSeconds(next), "Clash", a);
        switch (reason)
        {
            case "missing counter":
                ConnectionInfo missing = Download("new", "app.exe", 0); missing.HasTrafficCounters = false;
                interruption.Connections.Add(missing); break;
            case "counter rollback": a.DownloadBytes = 0; break;
            case "pause": alerts.ResetBaseline(); break;
            case "Windows": interruption.SourceName = "Windows 系统连接"; interruption.ClashConnected = false; break;
            case "disappeared": interruption.Connections.Clear(); break;
            case "slow": a.DownloadBytes = 12 * MiB; break;
            case "controller": interruption.ControllerSummary = "other"; break;
        }
        alerts.Update(interruption, null);
        sample(next + 1); sample(next + 2);
        Check(events.Count == 0, "Download counted across interruption: " + reason);
        sample(next + 3); sample(next + 4);
        Check(events.Count == 1, "Download failed to recover after interruption: " + reason);
    }

    private static void SustainedUpload()
    {
        DateTime at = new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        DateTime clock = at;
        ActivityAlerts alerts = new ActivityAlerts(delegate { return clock; });
        List<string> events = new List<string>(); alerts.Alert += events.Add;
        Check(!alerts.SustainedUploadEnabled && alerts.SustainedUploadSeconds == 10 && alerts.SustainedUploadBytesPerSecond == 1048576, "Upload rule defaults incorrect");
        alerts.Enabled = true; alerts.SustainedUploadEnabled = true;
        for (int i = 0; i <= 9; i++)
        {
            ConnectionInfo a = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); a.UploadBytes = i * 1048576L;
            alerts.Update(Snapshot(at.AddSeconds(i), "Clash", a), null);
        }
        Check(events.Count == 0, "Triggered before ten seconds of valid upload");
        ConnectionInfo tenth = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); tenth.UploadBytes = 10 * 1048576L;
        alerts.Update(Snapshot(at.AddSeconds(10), "Clash", tenth), null);
        Check(events.Count == 1 && events[0].Contains("1 MiB/s") && events[0].Contains("10 秒") && !events[0].Contains("192.0.2") && !events[0].Contains("a.exe"), "Ten-second trigger, parameters or notification privacy incorrect");
        for (int i = 11; i <= 15; i++) { ConnectionInfo a = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); a.UploadBytes = i * 1048576L; alerts.Update(Snapshot(at.AddSeconds(i), "Clash", a), null); }
        Check(events.Count == 1, "Upload cooldown failed");
        clock = clock.AddMinutes(6); alerts.ResetBaseline();
        ConnectionInfo first = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); first.UploadBytes = 0;
        alerts.Update(Snapshot(at.AddSeconds(20), "Clash", first), null);
        for (int i = 1; i <= 6; i++) { ConnectionInfo a = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); a.UploadBytes = i * 1048576L; alerts.Update(Snapshot(at.AddSeconds(20 + i), "Clash", a), null); }
        ConnectionInfo reset = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); reset.UploadBytes = 0;
        alerts.Update(Snapshot(at.AddSeconds(27), "Clash", reset), null);
        for (int i = 1; i <= 9; i++) { ConnectionInfo a = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); a.UploadBytes = i * 1048576L; alerts.Update(Snapshot(at.AddSeconds(27 + i), "Clash", a), null); }
        Check(events.Count == 1, "Counter reset did not break sustained window");
        reset.UploadBytes = 10 * 1048576L; alerts.Update(Snapshot(at.AddSeconds(37), "Clash", reset), null);
        Check(events.Count == 2, "Sustained window failed after counter reset");
        alerts.ResetBaseline(); clock = clock.AddMinutes(6);
        for (int i = 0; i <= 6; i++) { ConnectionInfo a = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); a.UploadBytes = i * 1048576L; alerts.Update(Snapshot(at.AddSeconds(40 + i), "Clash", a), null); }
        ConnectionInfo partial = Row("missing", "C:\\Example\\b.exe", "b.exe", 22, "192.0.2.2", 0); partial.HasTrafficCounters = false;
        ConnectionInfo good = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); good.UploadBytes = 7 * 1048576L;
        alerts.Update(Snapshot(at.AddSeconds(47), "Clash", good, partial), null);
        for (int i = 8; i <= 16; i++) { ConnectionInfo a = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); a.UploadBytes = i * 1048576L; alerts.Update(Snapshot(at.AddSeconds(40 + i), "Clash", a), null); }
        Check(events.Count == 2, "Missing counter did not break sustained window");
        alerts.ResetBaseline();
        for (int i = 0; i <= 6; i++) { ConnectionInfo a = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); a.UploadBytes = i * 1048576L; alerts.Update(Snapshot(at.AddSeconds(60 + i), "Clash", a), null); }
        for (int i = 7; i <= 16; i++) { ConnectionInfo a = Row("upload", "C:\\Example\\a.exe", "a.exe", 21, "192.0.2.1", 0); a.UploadBytes = i * 1048576L; alerts.Update(Snapshot(at.AddSeconds(66 + i), "Clash", a), null); }
        Check(events.Count == 2, "Sampling gap did not break sustained window");
        bool bad = false; try { alerts.SustainedUploadSeconds = 0; } catch (ArgumentOutOfRangeException) { bad = true; }
        Check(bad, "Invalid duration accepted");
    }
    private static void Run()
    {
        DateTime clock = new DateTime(2026, 1, 1, 12, 0, 0, DateTimeKind.Utc);
        DateTime sample = clock;
        ActivityAlerts alerts = new ActivityAlerts(delegate { return clock; });
        List<string> events = new List<string>(); alerts.Alert += events.Add;
        int lookups = 0;
        Func<string, string> resolver = delegate(string ip) { lookups++; return ip == "192.0.2.1" ? "US" : ip == "192.0.2.2" ? "JP" : ip == "192.0.2.3" ? "DE" : "FR"; };
        ConnectionInfo a = Row("a", "C:\\Example\\a.exe", "a.exe", 20, "192.0.2.1", 0);
        alerts.Update(Snapshot(sample, "Clash", a), resolver);
        Check(!alerts.Enabled && lookups == 0 && events.Count == 0, "Default-disabled alerts scanned data");
        alerts.NewProgramsEnabled = true; alerts.NewCountriesEnabled = true; alerts.HighTrafficEnabled = true; alerts.HighTrafficBytesPerSecond = 1024; alerts.Enabled = true;
        alerts.Update(Snapshot(sample, "Clash", a), resolver);
        Check(lookups == 1 && events.Count == 0, "First sample emitted alerts");
        sample = sample.AddSeconds(1);
        ConnectionInfo pidChanged = Row("a", "C:\\Example\\a.exe", "a.exe", 200, "192.0.2.1", 1000);
        alerts.Update(Snapshot(sample, "Clash", pidChanged), resolver);
        Check(events.Count == 0, "PID change treated as a new program or usable speed");
        sample = sample.AddSeconds(1);
        ConnectionInfo faster = Row("a", "C:\\Example\\a.exe", "a.exe", 200, "192.0.2.1", 5000);
        ConnectionInfo b = Row("b", "C:\\Example\\b.exe", "b.exe", 200, "192.0.2.2", 0);
        alerts.Update(Snapshot(sample, "Clash", faster, b), resolver);
        Check(events.Count == 3 && events.Any(x => x.Contains("程序")) && events.Any(x => x.Contains("地区")) && events.Any(x => x.Contains("流量")), "Expected one new program, country and traffic alert");
        Check(events.All(x => !x.Contains("192.0.2") && !x.Contains("Example") && !x.Contains(".exe") && !x.Contains("example.test")), "Sensitive data escaped into notification");

        clock = clock.AddMinutes(1); sample = sample.AddSeconds(1);
        ConnectionInfo c = Row("c", "C:\\Example\\c.exe", "c.exe", 300, "192.0.2.3", 0);
        alerts.Update(Snapshot(sample, "Clash", faster, b, c), resolver);
        Check(events.Count == 3, "Per-category throttle failed");
        clock = clock.AddMinutes(5); sample = sample.AddSeconds(1);
        ConnectionInfo d = Row("d", "C:\\Example\\d.exe", "d.exe", 400, "192.0.2.4", 0);
        alerts.Update(Snapshot(sample, "Clash", faster, b, c, d), resolver);
        Check(events.Count == 5, "New programs/countries not alerted after cooldown");
        alerts.ResetBaseline(); sample = sample.AddSeconds(20);
        ConnectionInfo e = Row("e", "C:\\Example\\e.exe", "e.exe", 500, "192.0.2.5", 0);
        alerts.Update(Snapshot(sample, "Clash", faster, b, c, d, e), resolver);
        Check(events.Count == 5, "Pause/resume emitted retrospective new-activity alert");
        sample = sample.AddSeconds(1); alerts.Update(Snapshot(sample, "Clash", faster, b, c, d, e), resolver);
        Check(events.Count == 5, "Existing programs re-alerted after resume");
        sample = sample.AddSeconds(1);
        NetworkSnapshot failed = Snapshot(sample, "Clash", faster); failed.ClashConnected = false;
        alerts.Update(failed, resolver);
        sample = sample.AddSeconds(1); alerts.Update(Snapshot(sample, "Clash", faster, b, c, d, e), resolver);
        Check(events.Count == 5, "Disconnect/reconnect emitted retrospective alerts");
        sample = sample.AddSeconds(1); alerts.Update(Snapshot(sample, "Windows 系统连接", faster, b), resolver);
        Check(events.Count == 5, "Source switch emitted alerts");
        sample = sample.AddSeconds(20); alerts.Update(Snapshot(sample, "Windows 系统连接", faster, b, c), resolver);
        Check(events.Count == 5, "Stale interval emitted alerts");
        int before = lookups; alerts.Enabled = false; sample = sample.AddSeconds(1); alerts.Update(Snapshot(sample, "Clash", d), resolver);
        Check(lookups == before && events.Count == 5, "Disabled mode continued querying countries");
        alerts.Enabled = true; sample = sample.AddSeconds(1); alerts.Update(Snapshot(sample, "Clash", faster, b, c, d, e), resolver);
        Check(events.Count == 5, "Re-enable failed to establish baseline");
        bool rejected = false; try { alerts.HighTrafficBytesPerSecond = Double.NaN; } catch (ArgumentOutOfRangeException) { rejected = true; }
        Check(rejected, "Invalid threshold accepted");
        sample = sample.AddSeconds(1); alerts.Update(Snapshot(sample, "Clash", faster, b), delegate(string ip) { throw new InvalidOperationException(); });
        Check(events.Count == 5, "Unavailable country cache caused a spurious alert");
    }
    private static void Check(bool ok, string message) { checks++; if (!ok) throw new Exception(message); }
    private static NetworkSnapshot Snapshot(DateTime at, string source, params ConnectionInfo[] rows)
    { return new NetworkSnapshot { CapturedAt = at, SourceName = source, ControllerSummary = source, ClashConnected = source == "Clash", Connections = new List<ConnectionInfo>(rows) }; }
    private static ConnectionInfo Row(string id, string path, string name, int pid, string ip, long download)
    { return new ConnectionInfo { Id = id, Protocol = "TCP", LocalAddress = "127.0.0.1", LocalPort = 5000, RemoteAddress = ip, RemotePort = 443, ProcessId = pid, ProcessName = name, ProcessPath = path, Host = "example.test", DataSource = "Clash / Mihomo", HasTrafficCounters = true, DownloadBytes = download, UploadBytes = 0 }; }
}
