using System.Reflection;

[assembly: AssemblyTitle("RouteLens")]
[assembly: AssemblyProduct("RouteLens")]
[assembly: AssemblyDescription("Windows network observation for Clash / Mihomo")]
[assembly: AssemblyVersion("7.3.0.0")]
[assembly: AssemblyFileVersion("7.3.0.0")]
[assembly: AssemblyInformationalVersion("7.3.0")]
