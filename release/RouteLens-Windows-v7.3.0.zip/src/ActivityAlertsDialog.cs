using System;
using System.Drawing;
using System.Windows.Forms;

namespace RouteLens
{
    public sealed class ActivityAlertsDialog : Form
    {
        private readonly ActivityAlerts _alerts;
        private readonly CheckBox _enabled, _programs, _countries, _traffic, _upload, _download;
        private readonly NumericUpDown _threshold, _uploadThreshold, _uploadSeconds, _downloadThreshold, _downloadSeconds;
        public ActivityAlertsDialog(ActivityAlerts alerts)
        {
            if (alerts == null) throw new ArgumentNullException("alerts");
            _alerts = alerts; Text = "联网提醒"; StartPosition = FormStartPosition.CenterParent; ShowInTaskbar = false;
            BackColor = UiPalette.Canvas; ForeColor = UiPalette.Ink; Font = UiPalette.Body(9.5f);
            AutoScaleMode = AutoScaleMode.Dpi; AutoScaleDimensions = new SizeF(96, 96);
            Size = new Size(720, 670); MinimumSize = new Size(650, 630); Padding = new Padding(22); MinimizeBox = false;

            TableLayoutPanel layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Margin = new Padding(0) };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 45)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 48)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
            Controls.Add(layout);
            Label title = new Label { Text = "联网提醒", Dock = DockStyle.Fill, Font = UiPalette.Body(19), ForeColor = UiPalette.Ink, Margin = new Padding(0), AutoEllipsis = true };
            Label caption = new Label { Text = "首次采样用于建立基线。流量提醒仅统计 Clash 已计速连接。高速下载按程序分别提醒，每个程序最多每 5 分钟一次。", Dock = DockStyle.Fill, Font = UiPalette.Body(9), ForeColor = UiPalette.Muted, Margin = new Padding(0), AutoEllipsis = false };
            layout.Controls.Add(title, 0, 0); layout.Controls.Add(caption, 0, 1);

            RoundedPanel card = new RoundedPanel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(18, 12, 18, 12), Margin = new Padding(0), Radius = 14 };
            TableLayoutPanel settings = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 1, RowCount = 9, Margin = new Padding(0), BackColor = UiPalette.Surface };
            settings.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            foreach (int height in new[] { 34, 34, 34, 34, 40, 34, 40, 34, 40 })
                settings.RowStyles.Add(new RowStyle(SizeType.Absolute, height));
            _enabled = Check("启用联网提醒", alerts.Enabled); _enabled.Font = new Font("Microsoft YaHei UI", 10, FontStyle.Bold);
            _programs = Check("新程序首次联网", alerts.NewProgramsEnabled);
            _countries = Check("新目标地区", alerts.NewCountriesEnabled);
            _traffic = Check("Clash 流量达到阈值", alerts.HighTrafficEnabled);
            settings.Controls.Add(_enabled, 0, 0); settings.Controls.Add(_programs, 0, 1); settings.Controls.Add(_countries, 0, 2); settings.Controls.Add(_traffic, 0, 3);
            FlowLayoutPanel thresholdRow = new FlowLayoutPanel { Dock = DockStyle.Fill, Margin = new Padding(27, 0, 0, 0), WrapContents = false, BackColor = UiPalette.Surface };
            Label thresholdLabel = new Label { Text = "总速度阈值", Font = UiPalette.Body(9), ForeColor = UiPalette.Muted, Size = new Size(96, 30), TextAlign = ContentAlignment.MiddleLeft, Margin = new Padding(0, 2, 8, 0) };
            _threshold = new NumericUpDown { BackColor = UiPalette.Surface, ForeColor = UiPalette.Ink, Width = 100, Height = 30, Minimum = 1, Maximum = 10240, DecimalPlaces = 1, Increment = 1, Font = UiPalette.Body(9.5f), Margin = new Padding(0, 3, 7, 0), AccessibleName = "总速度提醒阈值，单位 MB 每秒" };
            _threshold.Value = Math.Max(_threshold.Minimum, Math.Min(_threshold.Maximum, (decimal)(alerts.HighTrafficBytesPerSecond / (1024d * 1024))));
            Label unit = new Label { Text = "MB/s", Font = UiPalette.Mono(9), ForeColor = UiPalette.Muted, Size = new Size(60, 30), TextAlign = ContentAlignment.MiddleLeft, Margin = new Padding(0, 2, 0, 0) };
            thresholdRow.Controls.Add(thresholdLabel); thresholdRow.Controls.Add(_threshold); thresholdRow.Controls.Add(unit); settings.Controls.Add(thresholdRow, 0, 4);
            _upload = Check("持续上传观察", alerts.SustainedUploadEnabled); settings.Controls.Add(_upload, 0, 5);
            settings.Controls.Add(RateAndDuration("上传", alerts.SustainedUploadBytesPerSecond, alerts.SustainedUploadSeconds, out _uploadThreshold, out _uploadSeconds), 0, 6);
            _download = Check("单个程序高速下载", alerts.ProgramDownloadEnabled); settings.Controls.Add(_download, 0, 7);
            settings.Controls.Add(RateAndDuration("下载", alerts.ProgramDownloadBytesPerSecond, alerts.ProgramDownloadSeconds, out _downloadThreshold, out _downloadSeconds), 0, 8);
            card.Controls.Add(settings); layout.Controls.Add(card, 0, 2);
            Label note = new Label { Text = "默认关闭；仅在本次运行中生效，关闭后清除本次基线。系统通知不会包含域名、IP 或程序路径。", Dock = DockStyle.Fill, ForeColor = UiPalette.Muted, Font = UiPalette.Body(8.7f), Margin = new Padding(0, 8, 0, 0) };
            layout.Controls.Add(note, 0, 3);
            FlowLayoutPanel actions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Margin = new Padding(0), Padding = new Padding(0, 8, 0, 0) };
            Button save = new ModernButton { Text = "保存设置", Width = 120, Height = 38, Primary = true, Margin = new Padding(0, 0, 10, 0) };
            Button cancel = new ModernButton { Text = "取消", Width = 90, Height = 38, DialogResult = DialogResult.Cancel, Margin = new Padding(0) };
            save.Click += delegate
            {
                Apply();
                if (TopLevel) { DialogResult = DialogResult.OK; Close(); }
                else save.Text = "已保存设置";
            };
            actions.Controls.Add(save); actions.Controls.Add(cancel); layout.Controls.Add(actions, 0, 4); CancelButton = cancel;
            foreach (CheckBox option in new[] { _enabled, _programs, _countries, _traffic, _upload, _download })
                option.CheckedChanged += delegate { save.Text = "保存设置"; };
            foreach (NumericUpDown option in new[] { _threshold, _uploadThreshold, _uploadSeconds, _downloadThreshold, _downloadSeconds })
                option.ValueChanged += delegate { save.Text = "保存设置"; };
            foreach (CheckBox option in new[] { _enabled, _traffic, _upload, _download })
                option.CheckedChanged += delegate { SetOptionsEnabled(); };
            SetOptionsEnabled();
        }

        private static CheckBox Check(string text, bool value)
        { return new ModernCheck { Text = text, Checked = value, Dock = DockStyle.Fill, Margin = new Padding(0), AccessibleName = text }; }
        private static FlowLayoutPanel RateAndDuration(string direction, double rate, double duration, out NumericUpDown threshold, out NumericUpDown seconds)
        {
            FlowLayoutPanel row = new FlowLayoutPanel { Dock = DockStyle.Fill, Margin = new Padding(27, 0, 0, 0), WrapContents = false, BackColor = UiPalette.Surface };
            Label label = new Label { Text = direction + "速度至少", Font = UiPalette.Body(9), ForeColor = UiPalette.Muted, Size = new Size(96, 30), TextAlign = ContentAlignment.MiddleLeft, Margin = new Padding(0, 2, 8, 0) };
            threshold = new NumericUpDown { BackColor = UiPalette.Surface, ForeColor = UiPalette.Ink, Width = 75, Height = 30, Minimum = .1m, Maximum = 10240, DecimalPlaces = 1, Increment = .1m, Font = UiPalette.Body(9.5f), Margin = new Padding(0, 3, 7, 0), AccessibleName = "持续" + direction + "速度阈值，单位 MiB 每秒" };
            threshold.Value = Math.Max(threshold.Minimum, Math.Min(threshold.Maximum, (decimal)(rate / (1024d * 1024))));
            Label rateUnit = new Label { Text = "MiB/s  持续", Font = UiPalette.Body(9), ForeColor = UiPalette.Muted, Size = new Size(88, 30), TextAlign = ContentAlignment.MiddleLeft, Margin = new Padding(0, 2, 0, 0) };
            seconds = new NumericUpDown { BackColor = UiPalette.Surface, ForeColor = UiPalette.Ink, Width = 65, Height = 30, Minimum = 1, Maximum = 3600, Font = UiPalette.Body(9.5f), Margin = new Padding(0, 3, 7, 0), AccessibleName = "持续" + direction + "所需秒数" };
            seconds.Value = Math.Max(seconds.Minimum, Math.Min(seconds.Maximum, (decimal)duration));
            Label secondsUnit = new Label { Text = "秒", Font = UiPalette.Body(9), ForeColor = UiPalette.Muted, Size = new Size(24, 30), TextAlign = ContentAlignment.MiddleLeft, Margin = new Padding(0, 2, 0, 0) };
            row.Controls.AddRange(new Control[] { label, threshold, rateUnit, seconds, secondsUnit });
            return row;
        }
        private void SetOptionsEnabled()
        {
            _programs.Enabled = _countries.Enabled = _traffic.Enabled = _upload.Enabled = _download.Enabled = _enabled.Checked;
            _threshold.Enabled = _enabled.Checked && _traffic.Checked;
            _uploadThreshold.Enabled = _uploadSeconds.Enabled = _enabled.Checked && _upload.Checked;
            _downloadThreshold.Enabled = _downloadSeconds.Enabled = _enabled.Checked && _download.Checked;
        }
        private void Apply()
        {
            if (!_enabled.Checked) _alerts.Enabled = false;
            _alerts.NewProgramsEnabled = _programs.Checked; _alerts.NewCountriesEnabled = _countries.Checked; _alerts.HighTrafficEnabled = _traffic.Checked;
            _alerts.SustainedUploadEnabled = _upload.Checked; _alerts.SustainedUploadBytesPerSecond = (double)_uploadThreshold.Value * 1024 * 1024; _alerts.SustainedUploadSeconds = (double)_uploadSeconds.Value;
            _alerts.ProgramDownloadEnabled = _download.Checked; _alerts.ProgramDownloadBytesPerSecond = (double)_downloadThreshold.Value * 1024 * 1024; _alerts.ProgramDownloadSeconds = (double)_downloadSeconds.Value;
            _alerts.HighTrafficBytesPerSecond = (double)_threshold.Value * 1024 * 1024; _alerts.Enabled = _enabled.Checked;
        }
    }
}
